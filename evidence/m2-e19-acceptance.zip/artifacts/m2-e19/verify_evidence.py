import hashlib
import json
import math
import sqlite3
from pathlib import Path

ROOT = Path('artifacts/m2-e19')
REVISION = 'ff862a631bb5429044828013add41da7a313a202'
DATASET = 'f24e81c97227b0932978a240ae20411f6ffea7242bed11294c43b16ce9904568'


def read(path):
    return json.loads(path.read_bytes())


def verify_journal(path, report):
    candidate = report['plan']['candidate_id']
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
        assert db.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
        row = db.execute('SELECT run_id, execution_status FROM campaigns').fetchall()
        assert row == [(report['run_id'], 'COMPLETED')]
        row = db.execute('SELECT candidate_id, execution_status, metrics_json FROM experiments').fetchall()
        assert len(row) == 1 and row[0][:2] == (candidate, 'COMPLETED')
        assert json.loads(row[0][2]) == report['outcome']['result']


def verify_run(platform):
    cover_dir = ROOT / (platform + '-coverage')
    run_dir = ROOT / platform
    count = read(cover_dir / 'coverage.json')
    report = read(run_dir / 'report.json')
    verify_journal(cover_dir / 'research.sqlite3', count)
    verify_journal(run_dir / 'research.sqlite3', report)
    assert count['plan']['input_archives'] == report['plan']['input_archives']
    for receipt in (count, report):
        assert receipt['plan']['dataset_id'] == DATASET
        assert [x['day'] for x in receipt['plan']['input_archives']] == [f'2025-12-{n:02d}' for n in range(1, 11)]
    assert count['decision'] == 'QUALIFIED'
    assert count['outcome']['completed_fits'] == 2
    assert count['outcome']['result']['estimator_fits'] == 0
    assert report['source']['git'] == {'commit': REVISION, 'dirty': False}
    assert report['decision'] == 'DEFER'
    assert report['timing']['completed_fits'] == 1
    assert report['outcome']['completed_fits'] == 4
    result = report['outcome']['result']
    comparison = result['comparison']
    for role, trades in comparison['trades'].items():
        for trade in trades:
            assert trade['entry_index'] == trade['signal_index'] + 1
            assert trade['exit_index'] == trade['entry_index'] + 30
            assert trade['available_at'] == trade['entry_at']
            assert math.isclose(trade['gross_pnl'] - trade['net_pnl'], 0.0025, abs_tol=1e-12)
        expected = 10000 * math.fsum(t['net_pnl'] for t in trades)
        assert math.isclose(expected, comparison['aggregate']['policies'][role]['net_bps'], abs_tol=1e-10)
    for row, gate in zip((comparison['fold_1'], comparison['fold_2']), result['folds'], strict=True):
        expected = (row['policies']['hmm']['net_bps'] - row['policies']['rolling_volatility']['net_bps']) / row['eligible_count']
        assert math.isclose(gate['delta_net_bps_per_opportunity'], expected, abs_tol=1e-12)
    return count, report


maximum_difference = 0.0
compared = {'numeric': 0, 'discrete': 0}


def match(left, right, path='root'):
    global maximum_difference
    if isinstance(left, dict):
        assert left.keys() == right.keys(), path
        for key in left:
            match(left[key], right[key], f'{path}.{key}')
    elif isinstance(left, list):
        assert len(left) == len(right), path
        for index, (a, b) in enumerate(zip(left, right, strict=True)):
            match(a, b, f'{path}.{index}')
    elif isinstance(left, float):
        assert math.isclose(left, right, rel_tol=1e-8, abs_tol=1e-8), (path, left, right)
        maximum_difference = max(maximum_difference, abs(left - right))
        compared['numeric'] += 1
    else:
        assert left == right, (path, left, right)
        compared['discrete'] += 1


windows_count, windows = verify_run('windows')
ubuntu_count, ubuntu = verify_run('ubuntu')
assert windows['source']['files'] == ubuntu['source']['files']
match(windows_count['outcome']['result'], ubuntu_count['outcome']['result'])
match(windows['outcome']['result'], ubuntu['outcome']['result'])
print('Matched frozen source, counts, model diagnostics, policies and exact trade indices.')
print(compared, 'max absolute numerical difference', maximum_difference)
for name, report in (('windows', windows), ('ubuntu', ubuntu)):
    print(name, report['run_id'], hashlib.sha256((ROOT / name / 'report.json').read_bytes()).hexdigest())
