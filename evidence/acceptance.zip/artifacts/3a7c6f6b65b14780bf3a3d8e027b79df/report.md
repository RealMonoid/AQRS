# AQRS synthetic research report

Run **3a7c6f6b65b14780bf3a3d8e027b79df** ended with **REJECTED_PREFLIGHT**.

No real-world alpha has been demonstrated. This is a synthetic engineering exercise.
Observations and forward targets can overlap. No statistical significance is inferred.
Next-bar opens and constant illustrative costs approximate fills.

- Seed 42, scenario null, bar length 5 minutes, horizon 3 bars.
- Dataset fingerprint `27d67749e57b05086b66c23bbb2eae919fa8b8b07dec2cbc33e54677bd4743b2`.
- Configuration fingerprint `01a77e1e1949ff800f22396e060c15978b8535dd63c58f9a8f9786426f9bc94d`.
- Preflight ADMITTED, 0/2 trials started, 1/7 fits completed, including pilot.
- Memory mode observed_rss, sampled peak 116.9453125 MiB.
- Reserved holdout begins at 2024-02-03T08:00:00+00:00 and was not evaluated.
- Stop reason: Worker containment or observation failed (PermissionError).

## Cost assumptions

- `fee_bps_per_side` = 4.0 bps
- `quoted_spread_bps` = 3.0 bps
- `slippage_bps_per_side` = 2.0 bps
- `decision_buffer_bps` = 2.0 bps

## C_LAG

Execution **REJECTED_PREFLIGHT**, evidence **NOT_EVALUATED**.
Worker containment or observation failed (PermissionError).

## C_LAG_VOL

Execution **REJECTED_PREFLIGHT**, evidence **NOT_EVALUATED**.
Worker containment or observation failed (PermissionError).

See `report.json` for fold boundaries, fit metrics and individual simulated fills.
