# AQRS synthetic research report

Run **55ed0dc77ec44140a972eb9cfb7e6e69** ended with **COMPLETED**.

No real-world alpha has been demonstrated. This is a synthetic engineering exercise.
Observations and forward targets can overlap. No statistical significance is inferred.
Next-bar opens and constant illustrative costs approximate fills.

- Seed 42, scenario null, bar length 5 minutes, horizon 3 bars.
- Dataset fingerprint `632c9321082fc2efcf133d41041639a7e82524f5a5aef35c8f54d972e7c2be99`.
- Configuration fingerprint `01a77e1e1949ff800f22396e060c15978b8535dd63c58f9a8f9786426f9bc94d`.
- Preflight ADMITTED, 2/2 trials started, 7/7 fits completed, including pilot.
- Memory mode observed_rss, sampled peak 122.3984375 MiB.
- Sampled worker CPU time across pilot and trials was 2.700 seconds.
- Reserved holdout begins at 2024-02-03T08:00:00+00:00 and was not evaluated.

## Cost assumptions

- `fee_bps_per_side` = 4.0 bps
- `quoted_spread_bps` = 3.0 bps
- `slippage_bps_per_side` = 2.0 bps
- `decision_buffer_bps` = 2.0 bps

## C_LAG

Execution **COMPLETED**, evidence **INSUFFICIENT_EVIDENCE**.

Synthetic research folds are insufficient evidence of real-world alpha.

MAE on 2988 out-of-sample observations was 0.00209679; zero-return MAE was 0.00209496. MAE is measured in simple returns and lower is better.

| Policy | Trades | Gross PnL | Net PnL | Turnover | Max drawdown |
|---|---:|---:|---:|---:|---:|
| candidate | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| momentum | 759 | -0.025025 | -1.163525 | 1518.000000 | 1.169924 |
| no_trade | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |

PnL, turnover and drawdown use abstract notional units. Higher net PnL and lower realized-equity drawdown are favorable.
Incremental net PnL against momentum was 1.163525.

## C_LAG_VOL

Execution **COMPLETED**, evidence **INSUFFICIENT_EVIDENCE**.

Synthetic research folds are insufficient evidence of real-world alpha.

MAE on 2988 out-of-sample observations was 0.00209527; zero-return MAE was 0.00209496. MAE is measured in simple returns and lower is better.

| Policy | Trades | Gross PnL | Net PnL | Turnover | Max drawdown |
|---|---:|---:|---:|---:|---:|
| candidate | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| momentum | 759 | -0.025025 | -1.163525 | 1518.000000 | 1.169924 |
| no_trade | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |

PnL, turnover and drawdown use abstract notional units. Higher net PnL and lower realized-equity drawdown are favorable.
Incremental net PnL against momentum was 1.163525.

See `report.json` for fold boundaries, fit metrics and individual simulated fills.
