# AQRS real research report

Run **e1286897d9344fd5b4ce7375575fdea7** ended with **COMPLETED**.

No real-world alpha has been demonstrated. This is a one-day engineering pilot.
Observations and forward targets can overlap. No statistical significance is inferred.
Next-bar opens and constant illustrative costs approximate fills.

- Seed 42, scenario historical, bar length 1 minutes, horizon 15 bars.
- Dataset fingerprint `7ec539e452f4efc7063947409a905f9c3e975b06ddf2585d252cb1ef72457893`.
- Configuration fingerprint `b3bd360f48645c378b812888757db4338a4986284023dd64393ef9b441c5468d`.
- Preflight ADMITTED, 1/1 trials started, 1/3 fits completed, including pilot.
- Memory mode observed_rss, sampled peak 114.5859375 MiB.
- Sampled worker CPU time across pilot and trials was 3.234 seconds.
- Reserved holdout begins at 2026-01-06T00:00:00+00:00 and was not evaluated.
- Archive import took 0.015000 seconds.

## Cost assumptions

- `fee_bps_per_side` = 10.0 bps
- `quoted_spread_bps` = 1.0 bps
- `slippage_bps_per_side` = 2.0 bps
- `decision_buffer_bps` = 2.0 bps

## C_LAG

Execution **COMPLETED**, evidence **INSUFFICIENT_EVIDENCE**.

Training move scale does not clear illustrative costs and buffer.
- Feature calculation took 0.000000 seconds.
- Execution simulation was skipped.

See `report.json` for fold boundaries, fit metrics and individual simulated fills.
