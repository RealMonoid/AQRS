# AQRS real research report

Run **1aa63be4f18d4905a6b27cb19a9785f9** ended with **COMPLETED**.

No real-world alpha has been demonstrated. This is a one-day engineering pilot.
Observations and forward targets can overlap. No statistical significance is inferred.
Next-bar opens and constant illustrative costs approximate fills.

- Seed 42, scenario historical, bar length 1 minutes, horizon 30 bars.
- Dataset fingerprint `7ec539e452f4efc7063947409a905f9c3e975b06ddf2585d252cb1ef72457893`.
- Configuration fingerprint `cbff07e94cfc66a7b9e021fdb2dd88b04f8bb1d7f8c2698cedf185886a82fa16`.
- Preflight ADMITTED, 1/1 trials started, 3/3 fits completed, including pilot.
- Memory mode observed_rss, sampled peak 114.58984375 MiB.
- Sampled worker CPU time across pilot and trials was 3.172 seconds.
- Reserved holdout begins at 2026-01-06T00:00:00+00:00 and was not evaluated.
- Archive import took 0.000000 seconds.

## Cost assumptions

- `fee_bps_per_side` = 10.0 bps
- `quoted_spread_bps` = 1.0 bps
- `slippage_bps_per_side` = 2.0 bps
- `decision_buffer_bps` = 2.0 bps

## C_LAG

Execution **COMPLETED**, evidence **INSUFFICIENT_EVIDENCE**.

One day of research folds is insufficient evidence of real-world alpha.
- Feature calculation took 0.000000 seconds.
- Execution simulation took 0.000000 seconds.

MAE on 658 out-of-sample observations was 0.00220230; zero-return MAE was 0.00212675. MAE is measured in simple returns and lower is better.

| Policy | Trades | Gross PnL | Net PnL | Turnover | Max drawdown |
|---|---:|---:|---:|---:|---:|
| candidate | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| momentum | 1 | 0.004325 | 0.001825 | 2.000000 | 0.000000 |
| no_trade | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |

PnL, turnover and drawdown use abstract notional units. Higher net PnL and lower realized-equity drawdown are favorable.
Incremental net PnL against momentum was -0.001825.

See `report.json` for fold boundaries, fit metrics and individual simulated fills.
