# AQRS real research report

Run **a6e0494f2ee14c0e8485c033edbdf074** ended with **REJECTED_PREFLIGHT**.

No real-world alpha has been demonstrated. This is a one-day engineering pilot.
Observations and forward targets can overlap. No statistical significance is inferred.
Next-bar opens and constant illustrative costs approximate fills.

- Seed 42, scenario historical, bar length 1 minutes, horizon 30 bars.
- Dataset fingerprint `None`.
- Configuration fingerprint `57166dcda04144f0aa82e09aa2f5be09805e145a7a6cb2ff7175d1e79a90a09e`.
- Preflight REJECTED_PREFLIGHT, 0/1 trials started, 0/3 fits completed, including pilot.
- Memory mode observed_rss, sampled peak 87.71875 MiB.
- Sampled worker CPU time across pilot and trials was 2.375 seconds.
- Reserved holdout begins at 2026-01-06T00:00:00+00:00 and was not evaluated.
- Archive import took 0.015000 seconds.
- Stop reason: Pilot did not complete: Trial wall-time limit.

## Cost assumptions

- `fee_bps_per_side` = 10.0 bps
- `quoted_spread_bps` = 1.0 bps
- `slippage_bps_per_side` = 2.0 bps
- `decision_buffer_bps` = 2.0 bps

## C_LAG

Execution **REJECTED_PREFLIGHT**, evidence **NOT_EVALUATED**.
Pilot did not complete: Trial wall-time limit.

See `report.json` for fold boundaries, fit metrics and individual simulated fills.
