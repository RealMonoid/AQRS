# M2-E14 discovery comparison

Execution: COMPLETED. Dataset scope: 2025-12-25, 2025-12-26, 2025-12-27, 2025-12-28, 2025-12-29, 2025-12-30, 2025-12-31, 2026-01-01, 2026-01-02, 2026-01-03.
Claim scope: descriptive development results with illustrative costs.
Reserved fit and calibration charges: 3/7.

## VOL_CONFIRM_V1

COMPLETED
- coverage: PASS
- event_net_at_least_5_bps: MISS
- pair_difference_at_least_2_bps: MISS
Development screen: DEFER.

## RIDGE_INCREMENT_V1

SCREENED_OUT
Development screen: DEFER.
