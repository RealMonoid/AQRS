# M2-E18 discovery comparison

Execution: COMPLETED. Dataset scope: 2025-12-01, 2025-12-02, 2025-12-03, 2025-12-04, 2025-12-05, 2025-12-06, 2025-12-07, 2025-12-08, 2025-12-09, 2025-12-10.
Claim scope: descriptive development results with illustrative costs.
Reserved fit and calibration charges: 7/7.

## VOL_CONFIRM_E18_V1

COMPLETED
- coverage: PASS
- event_net_at_least_5_bps: MISS
- pair_difference_at_least_2_bps: MISS
Development screen: DEFER.

## RIDGE_INCREMENT_E18_V1

COMPLETED
- coverage: MISS
- relative_mae_reduction_at_least_1_percent_each_fold: MISS
- net_at_least_5_bps_per_trade: MISS
- incremental_net_at_least_2_bps_per_eligible_opportunity: MISS
Development screen: DEFER.
